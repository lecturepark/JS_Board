package Board2;

public class Post2 {
	String title;
	String content;
	String id;
	int num;

	public Post2(String title, String content, String id, int num) {
		this.title = title;
		this.content = content;
		this.id = id;
		this.num = num;

	}
}
